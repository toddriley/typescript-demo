export const gifIds = [
  { id: "", name: "" },
  { id: "xT4uQulxzV39haRFjG", name: "Tacos" },
  { id: "3og0IPxMM0erATueVW", name: "Fetch" },
  { id: "sdAzR8WM8bZuw", name: "IntelliSense" },
  { id: "3o7btXIelzs8nBnznG", name: "Tennis" }
];
